# Evidence index

Final production extension hash and source binding: `installed-source.json` and `browser-install.log`. All twenty loaded extension files match local corrected source. Final version: 2.1.2.

Current validation:

- `final-node.log`: 278 passed, zero failed/skipped, exit 0.
- `final-browser-suite.log`: six actual-browser command groups, each EXIT 0 (popup, DOM boundaries, real MathQuill, full two-lane workflow, recovery, reload).
- `browser-install.log`: additional fresh installation/source-byte/host-permission check, exit 0.
- `browser-manual.log`: additional actual-popup manual worker insertion check, exit 0.
- `browser-events.json`: real browser fixture media/time/Check/feedback/Next/Done events; zero page errors. No live-site or course-credit claim.
- `popup-before.png`, `popup-after.png`, `popup-paused.png`: actual action popup screenshots.
- `input-identity.json`, `baseline-node.log`: verified input archive and original 275-test baseline.

Regressions before correction: `popup-before.log`, `rapid-stop-before.log`, `question-scope-before.log`, `feedback-before.log`, `mathquill-stateless-before.log`.

Other logs and `original/` preserve intermediate diagnosis and unmodified original snippets. They are historical, not final passing results. In particular, `mathquill-probe.log` is an exploratory value trace, not an assertion-based passing test, and the initial Chromium/fixture/harness failures are not the final extension outcome. The original handoff's 275-test report is preserved under `original/`.

All classroom URLs, responses, answers and identifiers in browser evidence belong to synthetic local fixtures. No browser credentials, student records, cookies or private screenshots were accessed or exported.

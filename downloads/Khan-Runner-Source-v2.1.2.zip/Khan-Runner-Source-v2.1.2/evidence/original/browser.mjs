// Actual MV3 extension test, with all classroom requests fulfilled by local synthetic fixtures.
// A real Playwright Chromium executable is required. No Khan credentials or live course is used.
import {createRequire} from 'node:module';import {mkdtemp,rm,readFile} from 'node:fs/promises';import {tmpdir} from 'node:os';import path from 'node:path';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';
const require=createRequire(import.meta.url),{chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const extension=fileURLToPath(new URL('../extension/',import.meta.url)),profile=await mkdtemp(path.join(tmpdir(),'khan-dual-test-'));
const ROOT='https://classroom.khanacademy.org/learner/class/FIXTURE';let context;
const list=`<!doctype html><html><body><h1>All assignments</h1><select aria-label="Assignment Status"><option selected>To-do</option></select><table><tr><td><a href="${ROOT}/assignment/video1">Test video</a></td><td>Video</td></tr><tr><td><a href="${ROOT}/assignment/exercise1">Factor quadratics</a></td><td>Exercise</td></tr></table><p>Current page: 1 of 1.</p></body></html>`;
const video=`<!doctype html><html><body><h1>Test video</h1><video style="width:320px;height:180px" src="https://classroom.khanacademy.org/fixture-video.webm" preload="auto"></video></body></html>`;
const exercise=`<!doctype html><html><body><header>1 of 1 questions</header><main><p>Factor the quadratic expression completely.</p><math><semantics><annotation encoding="application/x-tex">10x^2+13x+4</annotation></semantics></math><input aria-label="Answer"><button id="check">Check</button><p role="status" id="feedback"></p><button id="done" hidden>Done</button></main><script>window.submits=0;document.getElementById('check').onclick=()=>{window.submits++;const value=document.querySelector('input').value.replace(/[ *]/g,'');if(value==='(2x+1)(5x+4)'||value==='(5x+4)(2x+1)'){document.getElementById('feedback').textContent='Correct!';document.getElementById('check').hidden=true;document.getElementById('done').hidden=false;}else document.getElementById('feedback').textContent='Incorrect';};document.getElementById('done').onclick=()=>{document.querySelector('main').innerHTML='<p role="status">Exercise complete</p>';};</script></body></html>`;
try{
 context=await chromium.launchPersistentContext(profile,{channel:'chromium',headless:true,args:['--no-sandbox',`--disable-extensions-except=${extension}`,`--load-extension=${extension}`]});
 const media=await readFile(new URL('./fixtures/sample.webm',import.meta.url));
 await context.route('https://classroom.khanacademy.org/**',route=>{const u=route.request().url();return u.endsWith('/fixture-video.webm')?route.fulfill({status:200,contentType:'video/webm',body:media}):route.fulfill({status:200,contentType:'text/html',body:u.includes('/assignment/video')?video:u.includes('/assignment/exercise')?exercise:list});});
 let [worker]=context.serviceWorkers();worker||=await context.waitForEvent('serviceworker',{timeout:10000});const id=new URL(worker.url()).host;
 const source=await context.newPage();await source.goto(ROOT);await source.waitForSelector('table');
 const tabId=await worker.evaluate(async()=>{const tabs=await chrome.tabs.query({});return tabs.find(t=>t.url?.endsWith('/class/FIXTURE')).id;});
 const control=await context.newPage();await control.goto(`chrome-extension://${id}/popup.html`);
 const ask=(type,data={})=>control.evaluate(m=>chrome.runtime.sendMessage(m),{type,tabId,...data});
 const started=await ask('AUTO_START',{rate:2,muted:true});assert.ok(started.ok,JSON.stringify(started));
 const deadline=Date.now()+120000;let state;
 while(Date.now()<deadline){state=(await ask('AUTO_STATUS')).run;if(!state.running)break;await new Promise(resolve=>setTimeout(resolve,1000));}
 assert.equal(state.state,'DONE',JSON.stringify(state));assert.equal(state.counts.video,1);assert.equal(state.counts.exercise,1);assert.equal(state.counts.answers,1);
 const problem=context.pages().find(p=>p.url().includes('/assignment/exercise'));assert.ok(problem);assert.equal(await problem.evaluate(()=>window.submits),1);
 const local=await context.newPage();await local.goto(`chrome-extension://${id}/selftest.html`);await local.waitForFunction(()=>document.getElementById('summary').textContent.includes('local checks passed'));assert.match(await local.locator('#summary').textContent(),/^15\/15/);
 await ask('AUTO_STOP');assert.equal((await ask('AUTO_STATUS')).run.running,false);
 console.log('PASS: actual MV3 load, class-list discovery, two actual tabs, native muted video autoplay/end, exact factor insertion, one Check click, site-fixture completion observation, STOP, and 15 in-browser local checks. Synthetic classroom only.');
}finally{await context?.close();await rm(profile,{recursive:true,force:true});}

# Release evidence · 2.1.1 · 2026-10-25

**Story:** Start from the owner's Khan classroom assignment list → collect same-class queued items → run a video tab and an automatic exercise tab → observe media ends and actual exercise completion UI → continue or expose a specific pause.

## Corrected behavior

The 2.0 build was an assistance tool: Start changed playback rate but did not autoplay, collect a queue, open a second worker tab, or click Check. The owner requested automatic operation. This update implements the two-tab controller and automatic supported-answer entry/Check/Next/Done. Missing global MathQuill API was a source-level compatibility risk, not a reproduced owner failure; the new textarea event fallback addresses that risk with readback and no private API access.

## Evidence

| Boundary | Result | Evidence |
|---|---|---|
| Math / symbolic normalization | PASS locally | Exact fractions/polynomials; rational GCD cancellation; standard trig identities checked against independent numerical values |
| Class list → queue | PASS in fixtures | Same-origin/class filtering, row Type column, deduplication and pagination |
| Queue → two managed tabs | PASS in controller simulation | Exactly one additional tab, independent lanes |
| Video play / end / Stop | PASS in media fixtures | Actual media function calls tested with simulated video objects; no seeking |
| Problem → solution → input → Check → next | PASS in controller simulation | Two videos, four accepted answer transitions, two exercise completions; exactly four Check clicks |
| Stale input / existing work / uncertain Check | PASS in fixtures | No overwrite; restart does not repeat submission; wrong answer pauses |
| MathQuill API and textarea fallback | PASS in interface simulations | Readback, negatives/fractions, stateless clipboard, copy/paste prevention and stale token checks |
| Static MV3 / assets / permission boundaries | PASS | Source/manifest checks and JS syntax |
| Complete local Node suite | **275 passed / 0 failed** | `test-results.txt`, actual process exit 0 |
| Actual Chromium extension loading | **BLOCKED** | Missing Chromium executable; earlier official download returned invalid archive |
| New real-browser two-tab test | **NOT RUN** | `tests/browser.mjs` plus original generated WebM fixture included |
| User's installed failure | **NOT REPRODUCED** | No owner diagnostics or connected signed-in tab available |
| Signed-in Khan / actual editor / course credit | **UNVERIFIED** | No live test, account changes, grade writes or credit claims |
| Firefox / Chrome Web Store | **NOT TARGETED / NOT PUBLISHED** | Local Chrome package only |

## Limits and failure recovery

This build cannot guarantee every exercise format. Graphs, multiple choice, multiple fields, systems, general word problems and unreadable expressions pause. Normal Khan markup or custom editor differences can still block real usage. The exact first failure is exposed in the lane status and sanitized diagnostic report. Controller sessions retain action intent across service-worker restart; unknown submission outcomes pause instead of being retried. Video-ended counts remain separate from site-confirmed exercise completion, and neither establishes independently verified course credit.

## Acceptance still required in the owner's Chrome

Install 2.1.1 with the old build removed. Run 15 local extension checks. On the To-do class list, Start both tabs and observe: one video truly starts at 2× and reaches its end; one supported exercise gets the intended answer, exactly one Check click, correct site feedback, Next/Done, and the next queued assignment. Test Stop while active. If a lane pauses, Copy diagnostics and report its code before restarting. A perfect or production-verified result is not claimed without this evidence.

## Architecture

`popup.js` provides the explicit automatic start/stop/resume controls plus a manual calculator. `worker.js` validates sender/frame authority and serializes operations. `dual.js` owns the durable queue, lane states, submission intent and alarm recovery. `runner-content.js` supplies bounded foreground/background page pulses. `automation-page.js` inspects/clicks ordinary visible UI and controls HTML5 media. `math.js` and `advanced-math.js` compute locally with restricted exact arithmetic. `input.js` and `mq-dom.js` enter and read back answers through native inputs or documented/public DOM editor behavior. The original assist adapter remains available to the manual calculator; the automatic controller stops its current-tab session before starting.

## 2.1.1 startup/status correction

The owner screenshot showed the popup on a valid To-do assignment list, with Connected ready, zero counters and no active lane. It did not expose a failure code or prove whether Start was clicked. Source inspection found that failures were rendered below the popup fold and the connection label did not distinguish an ERROR run. The correction surfaces failure at the top, adds sanitized startup probe counts, persists alarm/injection failures and performs the first discovery step directly from Start. New tests cover these specific behaviors, including no-timer startup and failed attachment. The actual owner-side cause is not claimed as reproduced.

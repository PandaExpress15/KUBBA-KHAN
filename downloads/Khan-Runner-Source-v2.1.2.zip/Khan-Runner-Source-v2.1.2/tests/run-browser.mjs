import {spawnSync} from 'node:child_process';
const scripts=['browser-install.mjs','browser-manual.mjs','browser-popup.mjs','browser-boundaries.mjs','browser-mathquill.mjs','browser.mjs','browser-recovery.mjs','browser-reload.mjs'];
for(const script of scripts){
 console.log('\nRUN node tests/'+script);
 const result=spawnSync(process.execPath,['tests/'+script],{stdio:'inherit',env:process.env});
 if(result.error)throw result.error;
 console.log('EXIT',result.status);
 if(result.status!==0)process.exit(result.status||1);
}

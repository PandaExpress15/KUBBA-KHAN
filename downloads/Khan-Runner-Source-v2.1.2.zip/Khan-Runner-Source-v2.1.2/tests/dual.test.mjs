import test from 'node:test';import assert from 'node:assert/strict';
import {DualRunner,classScope,collectJobs,problemKey,algebraEqual} from '../extension/dual.js';
import {pageSnapshot,pageAction,mediaStep,stopMedia,readEditor} from '../extension/automation-page.js';
import {insertReviewed} from '../extension/input.js';
const ROOT='https://classroom.khanacademy.org/learner/class/FIXTURE';
function fixture({pages=1,questions=2,wrong=false,unsupported=false,unknownSubmit=false,iframe=false,initialPage=1,articleFirst=false}={}){
 let time=100000,page=initialPage,nextId=20,checks=0,insertions=0,plays=0,stops=0;const storage={},tabs=new Map([[7,{id:7,url:ROOT}]]),models=new Map(),calls=[],alarms=new Set();
 const items=Array.from({length:pages},(_,i)=>[{url:ROOT+'/assignment/video'+i,kind:'video'},{url:ROOT+'/assignment/exercise'+i,kind:'exercise'}]);
 if(articleFirst)items[0]=[];
 function model(url){if(!models.has(url))models.set(url,{q:1,value:'',accepted:false,done:false,ended:false});return models.get(url);}
 const api={storage:{session:{async get(k){return {[k]:structuredClone(storage[k])};},async set(p){Object.assign(storage,structuredClone(p));}}},alarms:{async create(n){alarms.add(n);},async clear(n){alarms.delete(n);}},tabs:{async get(id){if(!tabs.has(id))throw Error('closed');return {...tabs.get(id)};},async update(id,p){Object.assign(tabs.get(id),p);return tabs.get(id);},async create(p){const t={id:nextId++,...p};tabs.set(t.id,t);return t;},async sendMessage(){return {ok:true};}},scripting:{async executeScript({target,func,args=[],files,world}){
  calls.push({target,name:func?.name||'files',args,world});if(files)return [{result:undefined}];
  const tab=tabs.get(target.tabId);if(!tab)throw Error('closed');const m=model(tab.url);let r;
  if(func===pageSnapshot){
   if(tab.url===ROOT)r={url:ROOT,token:ROOT+'|',items:items[page-1],assignmentCount:items[page-1].length||3,page,pages,isTodo:true,controls:page<pages?['Next']:[]};
   else{const expression=unsupported?'\\sin(x)':'10x^2+13x+4';r={url:tab.url,token:tab.url+'|'+expression,expression,operation:'factor',fieldCount:m.done?0:1,fieldValue:m.value,mathquill:false,ordinal:m.q,total:questions,accepted:m.accepted,negative:wrong&&m.accepted,done:m.done,radioCount:0,controls:m.done?[]:m.accepted?(m.q===questions?['Done']:['Next question']):['Check']};}
  }else if(func===pageAction){const [action]=args;if(action==='LIST_NEXT')page++;if(action==='LIST_PREVIOUS')page--;if(action==='CHECK'){checks++;if(!unknownSubmit)m.accepted=true;}if(action==='NEXT_QUESTION'){m.q++;m.value='';m.accepted=false;}if(action==='FINISH')m.done=true;r={ok:true};
  }else if(func===insertReviewed){insertions++;if(m.value)r={ok:false,error:'ANSWER_FIELD_NOT_EMPTY'};else{m.value=args[0].answer;r={ok:true,kind:'plain'};}}
  else if(func===mediaStep){plays++;r={videos:iframe&&target.frameIds[0]===0?[]:[{time:m.ended?10:time/1000,rate:2,duration:10,paused:false,ended:m.ended,error:''}]};}
  else if(func===stopMedia){stops++;r={ok:true};}else if(func===readEditor)r={ok:false};else throw Error('unknown function');
  return [{result:r,frameId:target.frameIds[0]}];
 }}};
 const runner=new DualRunner(api,()=>time);
 return {runner,api,tabs,models,calls,alarms,storage,advance(ms=5000){time+=ms;},endVideos(){for(const [url,m]of models)if(url.includes('/video'))m.ended=true;},get checks(){return checks;},get insertions(){return insertions;},get plays(){return plays;},get stops(){return stops;},async tick(){time+=5000;await runner.tick();}};
}
test('queue only accepts supported, same-class, unique assignment links',()=>{const q=collectJobs([{kind:'video',url:ROOT+'/assignment/1'},{kind:'video',url:ROOT+'/assignment/1#x'},{kind:'exercise',url:'https://evil.com/assignment/2'},{kind:'exercise',url:ROOT+'X/assignment/2'},{kind:'article',url:ROOT+'/assignment/3'}],ROOT);assert.equal(q.video.length,1);assert.equal(q.exercise.length,0);});
test('class scope only on actual classroom URL',()=>{assert.equal(classScope(ROOT+'/assignment/1'),ROOT);assert.throws(()=>classScope('https://www.khanacademy.org/math'));});
test('problem signatures distinguish repeated expression at another ordinal',async()=>{const p={url:ROOT+'/assignment/1',expression:'x+1',operation:'factor',ordinal:1};const key=await problemKey(p);assert.match(key,/^[a-f0-9]{64}$/);assert.notEqual(key,await problemKey({...p,ordinal:2}));assert.ok(!key.includes('x+1'));});
test('algebraic equivalence for input readback',()=>{assert.ok(algebraEqual('(2x+1)(5x+4)','10x^2+13x+4'));assert.ok(!algebraEqual('x+1','x+2'));assert.ok(!algebraEqual('', '0'));});
test('full coordinated two-tab flow: pagination, two videos, four answers, two exercise completions',async()=>{
 const f=fixture({pages:2,questions:2});await f.runner.start(7);assert.equal((await f.runner.get()).state,'DISCOVERING');
 await f.tick();await f.tick();let s=await f.runner.get();assert.equal(s.jobs.video.length,2);assert.equal(s.jobs.exercise.length,2);assert.equal(f.tabs.size,2);assert.equal(s.lanes.video.tabId,7);assert.notEqual(s.lanes.exercise.tabId,7);
 for(let i=0;i<30;i++){f.endVideos();await f.tick();if(!(await f.runner.get()).running)break;}
 s=await f.runner.get();assert.equal(s.state,'DONE',JSON.stringify(s));assert.equal(s.counts.video,2);assert.equal(s.counts.exercise,2);assert.equal(s.counts.answers,4);assert.equal(f.checks,4);assert.equal(f.insertions,4);assert.equal(f.alarms.size,0);
});
test('input insertion is verified on a later observation before Check',async()=>{const f=fixture();await f.runner.start(7);await f.tick();assert.equal(f.insertions,1);assert.equal(f.checks,0);await f.tick();assert.equal(f.checks,1);});
test('unsupported math pauses only exercise lane, video continues',async()=>{const f=fixture({unsupported:true});await f.runner.start(7);await f.tick();await f.tick();let s=await f.runner.get();assert.equal(s.lanes.exercise.error,'UNSUPPORTED_MATH_FORMAT');assert.equal(f.checks,0);assert.equal(s.lanes.video.state,'PLAYING');assert.equal(s.running,true);});
test('incorrect site feedback does not resubmit or advance',async()=>{const f=fixture({wrong:true});await f.runner.start(7);for(let i=0;i<8;i++)await f.tick();const s=await f.runner.get();assert.equal(s.lanes.exercise.error,'SITE_REJECTED_ANSWER');assert.equal(f.checks,1);assert.equal(s.counts.exercise,0);});
test('ambiguous submission is not retried after worker restart',async()=>{const f=fixture({unknownSubmit:true});await f.runner.start(7);for(let i=0;i<4;i++)await f.tick();assert.equal(f.checks,1);const restarted=new DualRunner(f.api,()=>200000);await restarted.tick();const s=await restarted.get();assert.equal(s.lanes.exercise.error,'SUBMISSION_RESULT_NOT_OBSERVED');assert.equal(f.checks,1);});
test('STOP all cancels future actions and pauses runner media',async()=>{const f=fixture();await f.runner.start(7);await f.tick();await f.tick();const before=f.checks;await f.runner.stop();await f.tick();assert.equal(f.checks,before);assert.ok(f.stops>0);assert.equal((await f.runner.get()).state,'STOPPED');assert.equal(f.alarms.size,0);});
test('closed exercise tab pauses with explicit code',async()=>{const f=fixture();await f.runner.start(7);await f.tick();const s=await f.runner.get();f.tabs.delete(s.lanes.exercise.tabId);await f.tick();assert.equal((await f.runner.get()).lanes.exercise.error,'WORKER_TAB_CLOSED');});
test('user navigation outside class blocks work in that lane',async()=>{const f=fixture();await f.runner.start(7);await f.tick();const s=await f.runner.get();f.tabs.get(s.lanes.exercise.tabId).url='https://example.com';await f.tick();assert.equal((await f.runner.get()).lanes.exercise.error,'WORKER_LEFT_CLASS_SCOPE');assert.equal(f.checks,0);});
test('scope-preserving unexpected assignment is not operated on',async()=>{const f=fixture();await f.runner.start(7);await f.tick();const s=await f.runner.get();f.tabs.get(s.lanes.exercise.tabId).url=ROOT+'/assignment/other';f.advance(31000);await f.tick();assert.equal((await f.runner.get()).lanes.exercise.error,'UNEXPECTED_PAGE_OR_NAVIGATION_TIMEOUT');assert.equal(f.checks,0);});
test('existing answer is never overwritten on automatic start',async()=>{const f=fixture();await f.runner.start(7);const s=await f.runner.get();f.models.set(s.jobs.exercise[0],{q:1,value:'my work',accepted:false,done:false});await f.tick();assert.equal((await f.runner.get()).lanes.exercise.error,'ANSWER_FIELD_NOT_EMPTY');assert.equal(f.checks,0);});
test('Khan media iframe registered before playback, without all-frame injection',async()=>{const f=fixture({iframe:true});await f.runner.start(7);await f.tick();await f.runner.frame({tab:{id:7,url:ROOT+'/assignment/video0'},frameId:2});await f.tick();const s=await f.runner.get();assert.equal(s.lanes.video.state,'PLAYING');assert.ok(f.calls.some(c=>c.name==='mediaStep'&&c.target.frameIds[0]===2));assert.ok(f.calls.every(c=>!c.target.allFrames));});
test('resume cannot forget an uncertain submission',async()=>{const f=fixture({unknownSubmit:true});await f.runner.start(7);for(let i=0;i<9;i++)await f.tick();assert.equal(f.checks,1);await f.runner.resume();await f.tick();assert.equal(f.checks,1);});
test('one active run prevents duplicate worker tabs',async()=>{const f=fixture();await f.runner.start(7);await assert.rejects(f.runner.start(7),/RUN_ALREADY_ACTIVE/);await f.tick();assert.equal(f.tabs.size,2);});
test('article-only list pages are passed without losing later video/exercise jobs',async()=>{const f=fixture({pages:2,articleFirst:true});await f.runner.start(7);await f.tick();await f.tick();const s=await f.runner.get();assert.equal(s.state,'RUNNING');assert.equal(s.jobs.video.length,1);assert.equal(s.jobs.exercise.length,1);});
test('starting on a later page first returns to page one',async()=>{const f=fixture({pages:3,initialPage:3});await f.runner.start(7);for(let i=0;i<5;i++)await f.tick();const s=await f.runner.get();assert.equal(s.jobs.video.length,3);assert.equal(s.jobs.exercise.length,3);assert.ok(f.calls.some(c=>c.name==='pageAction'&&c.args[0]==='LIST_PREVIOUS'));});
test('Start performs a real queue read before any content timer or alarm',async()=>{const f=fixture();const result=await f.runner.start(7);assert.ok(result.ok);assert.equal(result.run.state,'RUNNING');assert.equal(result.run.queued.video,1);assert.equal(f.tabs.size,2);assert.ok(f.calls.some(c=>c.name==='pageSnapshot'));});
test('heartbeat creation failure is a persisted startup error',async()=>{const f=fixture();f.api.alarms.create=async()=>{throw Error('alarm unavailable');};const r=await f.runner.start(7);assert.equal(r.ok,false);assert.equal(r.error,'STARTUP_ALARM_FAILED');const s=await f.runner.get();assert.equal(s.running,false);assert.equal(s.state,'ERROR');assert.equal(s.startupStage,'HEARTBEAT');});
test('content attachment failure cannot masquerade as connected ready',async()=>{const f=fixture();const original=f.api.scripting.executeScript;f.api.scripting.executeScript=async args=>{if(args.files)throw Error('Cannot access contents of url');return original(args);};const r=await f.runner.start(7);assert.equal(r.ok,false);assert.equal(r.error,'SITE_ACCESS_DENIED');assert.equal((await f.runner.get()).state,'ERROR');assert.equal(f.alarms.size,0);});

test('an expression change before accepted feedback is not credited or resubmitted',async()=>{
 const f=fixture({unknownSubmit:true});
 const original=f.api.scripting.executeScript;
 f.api.scripting.executeScript=async args=>{
  const r=await original(args);
  if(args.func===pageSnapshot&&f.checks&&f.tabs.get(args.target.tabId)?.url.includes('/assignment/exercise')){
   r[0].result.expression='x^2-1';r[0].result.token=r[0].result.url+'|x^2-1';
  }
  return r;
 };
 await f.runner.start(7);for(let i=0;i<6;i++)await f.tick();
 const s=await f.runner.get();assert.equal(s.lanes.exercise.error,'PROBLEM_CHANGED_BEFORE_FEEDBACK');
 assert.equal(s.counts.answers,0);assert.equal(f.checks,1);
});

test('Stop during asynchronous startup cannot be cleared by late tab lookup',async()=>{const f=fixture();const get=f.api.tabs.get;f.api.tabs.get=async id=>{f.runner.cancel();return get(id);};const r=await f.runner.start(7);assert.equal(r.error,'START_CANCELLED_BY_STOP');assert.equal(f.tabs.size,1);assert.equal((await f.runner.get()).running,false);});

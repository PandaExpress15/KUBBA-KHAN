import assert from 'node:assert/strict';
import {launch} from './browser-support.mjs';
import {pageSnapshot,pageAction} from '../extension/automation-page.js';
import {insertReviewed} from '../extension/input.js';
const b=await launch();
try{
 const page=await b.context.newPage();
 const url='https://classroom.khanacademy.org/learner/class/BOUNDARY/assignment/1';
 await b.context.route(url,r=>r.fulfill({contentType:'text/html',body:`<h1>Factoring title unrelated to the question</h1><aside hidden><math><annotation encoding="application/x-tex">x+9</annotation></math></aside><aside><button>Next question</button><p role="status">Correct!</p></aside><main data-testid="question"><p>Evaluate this exact trigonometric value.</p><math><annotation encoding="application/x-tex">\\sin(\\pi/6)</annotation></math><input aria-label="Answer"><button>Check</button><p role="status"></p></main>`}));
 await page.goto(url);
 const tabId=await b.worker.evaluate(async url=>(await chrome.tabs.query({})).find(t=>t.url===url).id,url);
 const invoke=(fn,args=[])=>b.worker.evaluate(`(async()=> (await chrome.scripting.executeScript({target:{tabId:${tabId}},func:${fn.toString()},args:${JSON.stringify(args)}}))[0].result)()`);
 const snapshot=await invoke(pageSnapshot);
 console.log('ACTUAL DOM SNAPSHOT',JSON.stringify(snapshot));
 assert.equal(snapshot.expression,'\\sin(\\pi/6)','hidden/unrelated math is excluded');
 assert.equal(snapshot.operation,'evaluate','title must not classify the current problem');
 assert.equal(snapshot.instruction,'Evaluate this exact trigonometric value.');assert.equal(snapshot.probe.instruction,undefined,'question instruction is not diagnostics');
 assert.equal(snapshot.accepted,false,'unrelated Next/Correct is not acceptance');
 await page.locator('main p').first().evaluate(e=>e.textContent='Evaluate the inverse sine.');await page.locator('main').evaluate(e=>e.insertAdjacentHTML('beforeend','<p id=units>Give your answer in degrees.</p>'));await page.locator('main annotation').first().evaluate(e=>e.textContent='asin(1/2)');const degrees=await invoke(pageSnapshot);assert.equal(degrees.unsupportedAnswerFormat,true);assert.match(degrees.instruction,/answer in degrees/);await page.locator('#units').evaluate(e=>e.remove());await page.locator('main p').first().evaluate(e=>e.textContent='Evaluate asin(1/2) in degrees.');assert.equal((await invoke(pageSnapshot)).unsupportedAnswerFormat,true);await page.locator('main').evaluate(e=>e.insertAdjacentHTML('beforeend','<p id=units>Give your answer in degrees.</p>'));await page.locator('#units').evaluate(e=>e.remove());await page.locator('main p').first().evaluate(e=>e.textContent='Evaluate this exact trigonometric value.');await page.locator('main annotation').first().evaluate(e=>e.textContent='\\sin(\\pi/6)');
 await page.locator('main button').evaluate(e=>e.remove());
 assert.equal((await invoke(pageSnapshot)).accepted,false,'unrelated feedback is not acceptance when Check disappears');
 const action=await invoke(pageAction,['NEXT_QUESTION',{url,token:snapshot.token}]);
 assert.equal(action.ok,false,'an unrelated Next must never be clicked');
 await page.locator('main').evaluate(e=>{e.insertAdjacentHTML('beforeend','<aside><p role="status">Exercise complete</p><math><annotation encoding="application/x-tex">x+99</annotation></math></aside>');});
 assert.equal((await invoke(pageSnapshot)).done,false,'a sidebar cannot complete the active exercise');
 assert.equal((await invoke(pageSnapshot)).expression,'\\sin(\\pi/6)','sidebar math is irrelevant');
 await page.locator('main p').first().evaluate(e=>e.textContent='Use a graph to determine the answer.');
 await page.locator('main').evaluate(e=>e.insertAdjacentHTML('afterbegin','<h1>Factor this assignment title</h1>'));
 await page.locator('main annotation').first().evaluate(e=>e.textContent='x^2-1');
 assert.equal((await invoke(pageSnapshot)).operation,null,'an assignment title cannot supply an unknown question directive');
 await page.locator('main p').first().evaluate(e=>e.textContent='Factor the expression.');
 await page.locator('input').fill('my existing work');
 const current=await invoke(pageSnapshot);
 const preserved=await invoke(insertReviewed,[{answer:'2',latex:'2'},current.token]);
 assert.equal(preserved.error,'ANSWER_FIELD_NOT_EMPTY');assert.equal(await page.locator('input').inputValue(),'my existing work');
 await page.locator('main annotation').first().evaluate(e=>e.textContent='x+1');
 const stale=await invoke(pageAction,['CHECK',{url,token:snapshot.token}]);assert.equal(stale.error,'STALE_PROBLEM');
 const unauthorized=await invoke(async function(){return chrome.runtime.sendMessage({type:'AUTO_START',tabId:1});});
 assert.equal(unauthorized.error,'UNKNOWN_CONTENT_ACTION','content frames cannot authorize Start');
 for(const raw of ['1 1/2','1\\frac{1}{2}','1 \\frac{ 1 }{ 2 }','1\\,\\frac{1}{2}']){
  await page.locator('main').evaluate((main,value)=>{main.innerHTML='<p>Evaluate the expression.</p><span id="mixed-stem"></span><fieldset><label><input type="radio" name="mixed">1.5</label><label><input type="radio" name="mixed">5.5</label></fieldset><button>Check</button>';const stem=main.querySelector('#mixed-stem');stem.setAttribute('data-tex',value);stem.textContent=value;},raw);
  const mixed=await invoke(pageSnapshot);assert.equal(mixed.unsupportedNotation,true,raw);assert.equal(mixed.expression,'',raw);assert.equal(mixed.probe.readState,'UNSUPPORTED_QUESTION_NOTATION');
 }
 console.log('PASS raw plain/TeX mixed-number stems rejected before normalization with competing 1.5/5.5 choices');
 console.log('PASS actual visible question scope, hidden-expression rejection, feedback and Next boundaries');
 console.log('PASS actual native existing-work preservation, stale Check rejection and content-frame authority');
}finally{await b.close();}
